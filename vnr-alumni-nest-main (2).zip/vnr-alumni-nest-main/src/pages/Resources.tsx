import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { FileText, CheckCircle, Download, Upload } from "lucide-react";
import { toast } from "sonner";

interface Resource {
  id: string;
  title: string;
  type: string;
  file_url: string;
  branch: string;
  semester: number;
  subject: string;
  verified: boolean;
  uploaded_at: string;
}

const Resources = () => {
  const [resources, setResources] = useState<Resource[]>([]);
  const [filteredResources, setFilteredResources] = useState<Resource[]>([]);
  const [loading, setLoading] = useState(true);
  const [branchFilter, setBranchFilter] = useState("");
  const [semesterFilter, setSemesterFilter] = useState("");
  const [typeFilter, setTypeFilter] = useState("");

  useEffect(() => {
    loadResources();
  }, []);

  useEffect(() => {
    filterResources();
  }, [resources, branchFilter, semesterFilter, typeFilter]);

  const loadResources = async () => {
    try {
      const { data, error } = await supabase
        .from('resources')
        .select('*')
        .order('uploaded_at', { ascending: false });

      if (error) throw error;
      setResources(data || []);
    } catch (error: any) {
      toast.error("Failed to load resources");
    } finally {
      setLoading(false);
    }
  };

  const filterResources = () => {
    let filtered = resources;

    if (branchFilter) {
      filtered = filtered.filter(r => r.branch === branchFilter);
    }

    if (semesterFilter) {
      filtered = filtered.filter(r => r.semester === parseInt(semesterFilter));
    }

    if (typeFilter) {
      filtered = filtered.filter(r => r.type === typeFilter);
    }

    setFilteredResources(filtered);
  };

  const branches = [...new Set(resources.map(r => r.branch))];
  const semesters = [...new Set(resources.map(r => r.semester))].sort();

  if (loading) {
    return <div>Loading resources...</div>;
  }

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-heading font-bold mb-2">Academic Resources</h1>
          <p className="text-muted-foreground">Access verified notes, papers, and study materials</p>
        </div>
        <Button size="lg">
          <Upload className="mr-2 h-5 w-5" />
          Upload Resource
        </Button>
      </div>

      {/* Filters */}
      <Card className="p-6">
        <div className="grid md:grid-cols-4 gap-4">
          <Select value={branchFilter} onValueChange={setBranchFilter}>
            <SelectTrigger>
              <SelectValue placeholder="All Branches" />
            </SelectTrigger>
            <SelectContent>
              {branches.map(branch => (
                <SelectItem key={branch} value={branch}>{branch}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={semesterFilter} onValueChange={setSemesterFilter}>
            <SelectTrigger>
              <SelectValue placeholder="All Semesters" />
            </SelectTrigger>
            <SelectContent>
              {semesters.map(sem => (
                <SelectItem key={sem} value={sem.toString()}>Semester {sem}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={typeFilter} onValueChange={setTypeFilter}>
            <SelectTrigger>
              <SelectValue placeholder="All Types" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="NOTES">Notes</SelectItem>
              <SelectItem value="OLD_PAPER">Previous Papers</SelectItem>
              <SelectItem value="MODEL_PAPER">Model Papers</SelectItem>
              <SelectItem value="CONCEPTS">Important Concepts</SelectItem>
              <SelectItem value="EXTRA">Extra Resources</SelectItem>
            </SelectContent>
          </Select>

          <Button
            variant="outline"
            onClick={() => {
              setBranchFilter("");
              setSemesterFilter("");
              setTypeFilter("");
            }}
          >
            Clear Filters
          </Button>
        </div>
      </Card>

      {/* Resources Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredResources.map((resource) => (
          <Card key={resource.id} className="p-6 hover-lift">
            <div className="space-y-4">
              <div className="flex items-start justify-between">
                <div className="p-3 rounded-lg bg-primary/10">
                  <FileText className="h-6 w-6 text-primary" />
                </div>
                {resource.verified && (
                  <Badge variant="default" className="bg-green-500">
                    <CheckCircle className="mr-1 h-3 w-3" />
                    Verified
                  </Badge>
                )}
              </div>

              <div>
                <h3 className="font-heading font-semibold text-lg mb-2">{resource.title}</h3>
                <div className="flex flex-wrap gap-2 mb-3">
                  <Badge variant="secondary">{resource.branch}</Badge>
                  <Badge variant="outline">Sem {resource.semester}</Badge>
                  <Badge variant="outline">{resource.type.replace('_', ' ')}</Badge>
                </div>
                <p className="text-sm text-muted-foreground">{resource.subject}</p>
              </div>

              <Button variant="default" size="sm" className="w-full">
                <Download className="mr-2 h-4 w-4" />
                Download
              </Button>
            </div>
          </Card>
        ))}
      </div>

      {filteredResources.length === 0 && (
        <Card className="p-12 text-center">
          <p className="text-muted-foreground">No resources found matching your filters</p>
        </Card>
      )}
    </div>
  );
};

export default Resources;
